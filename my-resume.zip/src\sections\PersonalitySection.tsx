import { useState, useEffect, useRef } from 'react';
import { personality, gameExperience } from '../data/profile';

export default function PersonalitySection() {
  const [hoverTrait, setHoverTrait] = useState<string | null>(null);
  const [typedText, setTypedText] = useState('');
  const [activeGameTab, setActiveGameTab] = useState(0);
  const typeRef = useRef<boolean>(false);

  // 打字效果
  useEffect(() => {
    if (typeRef.current) return;
    typeRef.current = true;
    const fullText = personality.intro;
    let idx = 0;
    const timer = setInterval(() => {
      if (idx <= fullText.length) {
        setTypedText(fullText.slice(0, idx));
        idx++;
      } else {
        clearInterval(timer);
      }
    }, 50);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="personality" className="py-20 px-6 pixel-grid-bg">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 mb-2 px-4 py-1 border-2 border-[#E8DDD4] bg-white">
            <span className="font-['Press_Start_2P'] text-[8px] text-[#8B8B8B]">SECTION 05</span>
          </div>
          <h2 className="font-['Press_Start_2P'] text-[#FF6B8A] text-xl md:text-2xl mt-3 mb-3">
            ✨ 个人性格
          </h2>
          <div className="pixel-divider max-w-xs mx-auto" />
        </div>

        <div className="grid md:grid-cols-5 gap-6">
          {/* 左栏 3/5 */}
          <div className="md:col-span-3 space-y-6">
            {/* 自我介绍 + 打字效果 */}
            <div className="pixel-card" style={{ borderColor: '#FF6B8A', boxShadow: '8px 8px 0 0 #FF6B8A22' }}>
              <div className="flex items-center gap-2 mb-4">
                <span className="font-['Press_Start_2P'] text-[11px] text-[#FF6B8A]">
                  {'>  About.Me_'}
                </span>
                <span className="w-2 h-4 bg-[#FF6B8A] animate-pulse" />
              </div>
              <p className="text-xl leading-relaxed text-[#4A4A4A] min-h-[72px]" style={{ fontFamily: "'VT323', 'Microsoft YaHei', 'PingFang SC', sans-serif" }}>
                {typedText}
                <span className="inline-block w-2 h-5 bg-[#FF6B8A] ml-1 animate-pulse align-middle" />
              </p>
            </div>

            {/* 性格特质 + 可交互条 */}
            <div className="pixel-card" style={{ borderColor: '#5B8DEF', boxShadow: '8px 8px 0 0 #5B8DEF22' }}>
              <h3 className="font-['Press_Start_2P'] text-[11px] text-[#5B8DEF] mb-5">
                {'>  Traits.exe_'}
              </h3>
              <div className="space-y-5">
                {personality.traits.map((trait) => (
                  <div
                    key={trait.name}
                    onMouseEnter={() => setHoverTrait(trait.name)}
                    onMouseLeave={() => setHoverTrait(null)}
                    className="cursor-pointer group"
                  >
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{trait.icon}</span>
                        <span className="font-['Press_Start_2P'] text-[9px] text-[#4A4A4A]">
                          {trait.name}
                        </span>
                      </div>
                      <span
                        className="font-['Press_Start_2P'] text-[8px] transition-all"
                        style={{
                          color: hoverTrait === trait.name ? trait.color : '#E8DDD4',
                        }}
                      >
                        {hoverTrait === trait.name ? `${trait.level}%` : '--%'}
                      </span>
                    </div>
                    <div className="pixel-skill-bar h-5 rounded-sm">
                      <div
                        className="pixel-skill-fill h-full transition-all duration-700"
                        style={{
                          width: hoverTrait === trait.name ? `${trait.level}%` : '0%',
                          backgroundColor: trait.color,
                        }}
                      />
                    </div>
                    {/* 悬停描述 */}
                    <div
                      className={`overflow-hidden transition-all duration-300 ${
                        hoverTrait === trait.name ? 'max-h-20 mt-2' : 'max-h-0'
                      }`}
                    >
                      <p className="text-base text-[#8B8B8B] leading-snug pl-7" style={{ fontFamily: "'VT323', 'Microsoft YaHei', 'PingFang SC', sans-serif" }}>
                        {trait.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-sm text-[#8B8B8B] mt-4 text-center" style={{ fontFamily: "'VT323', 'Microsoft YaHei', 'PingFang SC', sans-serif" }}>
                {'<< 悬停查看特质详情 >>'}
              </p>
            </div>

            {/* 游戏经历 */}
            <div className="pixel-card" style={{ borderColor: '#A66CFF', boxShadow: '8px 8px 0 0 #A66CFF22' }}>
              <h3 className="font-['Press_Start_2P'] text-[11px] text-[#A66CFF] mb-3">
                {'>  GameXP.db_'}
              </h3>
              <div className="flex flex-wrap gap-1.5 mb-4">
                {gameExperience.categories.map((cat, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveGameTab(i)}
                    className="font-['Press_Start_2P'] text-[7px] px-2.5 py-1.5 border-2 transition-all"
                    style={{
                      borderColor: activeGameTab === i ? '#A66CFF' : '#E8DDD4',
                      backgroundColor: activeGameTab === i ? '#A66CFF15' : 'transparent',
                      color: activeGameTab === i ? '#A66CFF' : '#8B8B8B',
                    }}
                  >
                    {cat.genre}
                  </button>
                ))}
              </div>
              <div className="min-h-[80px] p-3 border-2 border-dashed border-[#E8DDD4] bg-[#FFF8F0]/50">
                <p className="font-['VT323'] text-lg text-[#4A4A4A] mb-2">
                  {gameExperience.categories[activeGameTab].games}
                </p>
                <p className="font-['VT323'] text-sm text-[#8B8B8B] leading-snug">
                  {gameExperience.categories[activeGameTab].detail}
                </p>
              </div>
            </div>
          </div>

          {/* 右栏 2/5 */}
          <div className="md:col-span-2 space-y-6">
            {/* 爱好 */}
            <div className="pixel-card" style={{ borderColor: '#FFD93D', boxShadow: '8px 8px 0 0 #FFD93D22' }}>
              <h3 className="font-['Press_Start_2P'] text-[11px] text-[#E6C944] mb-4">
                {'>  Hobbies.list_'}
              </h3>
              <div className="flex flex-wrap gap-2">
                {personality.hobbies.map((hobby, i) => (
                  <span
                    key={i}
                    className="px-3 py-2 border-2 border-[#E8DDD4] hover:border-[#FFD93D] hover:bg-[#FFF9E0] transition-all cursor-default transform hover:-translate-y-0.5"
                    style={{ fontFamily: "'Press Start 2P', 'Microsoft YaHei', 'PingFang SC', sans-serif", fontSize: '8px' }}
                  >
                    {hobby}
                  </span>
                ))}
              </div>
            </div>

            {/* 关键词 */}
            <div className="pixel-card" style={{ borderColor: '#4ECDC4', boxShadow: '8px 8px 0 0 #4ECDC422' }}>
              <h3 className="font-['Press_Start_2P'] text-[11px] text-[#4ECDC4] mb-4">
                {'>  Keywords.map_'}
              </h3>
              <div className="flex flex-wrap gap-2">
                {personality.keywords.map((kw, i) => (
                  <span
                    key={i}
                    className="pixel-tag hover:scale-105 transition-transform cursor-default"
                    style={{
                      fontSize: '9px',
                      backgroundColor: ['#FFE8EC', '#E8F6FA', '#E8F8F3', '#FFF9E0', '#F3E8FF', '#FFF0E8'][i],
                      borderColor: ['#FF6B8A', '#7EC8E3', '#98D8C8', '#FFE066', '#C4A6FF', '#FF9A76'][i],
                    }}
                  >
                    {kw}
                  </span>
                ))}
              </div>
            </div>

            {/* 联系方式 + 游戏意向 */}
            <div className="pixel-card" style={{ borderColor: '#FF9A76', boxShadow: '8px 8px 0 0 #FF9A7622' }}>
              <h3 className="font-['Press_Start_2P'] text-[11px] text-[#FF9A76] mb-4">
                {'>  Contact.me_'}
              </h3>
              <div className="space-y-3 font-['VT323'] text-xl text-[#4A4A4A]">
                <div className="flex items-center gap-2 hover:text-[#FF6B8A] transition-colors">
                  <span>✉</span>
                  <a href={`mailto:${personality.contact.email}`}>
                    {personality.contact.email}
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <span>📱</span>
                  <span>{personality.contact.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span>📍</span>
                  <span>{personality.contact.location}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
