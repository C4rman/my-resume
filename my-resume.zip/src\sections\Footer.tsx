import { personalInfo } from '../data/profile';

export default function Footer() {
  return (
    <footer className="py-12 px-6 bg-[#4A4A4A] text-white">
      <div className="max-w-4xl mx-auto text-center">
        {/* 像素星星 */}
        <div className="flex justify-center gap-3 mb-6">
          {['★', '☆', '★', '☆', '★'].map((s, i) => (
            <span
              key={i}
              className="font-['Press_Start_2P'] text-lg"
              style={{
                color: ['#FF6B8A', '#FFD93D', '#4ECDC4', '#5B8DEF', '#A66CFF'][i],
                animation: `pixel-spin ${3 + i * 0.5}s linear infinite`,
              }}
            >
              {s}
            </span>
          ))}
        </div>

        <p className="font-['Press_Start_2P'] text-[10px] text-[#8B8B8B] mb-3">
          {personalInfo.name}
        </p>
        <p className="font-['VT323'] text-lg text-[#8B8B8B] mb-2">
          {personalInfo.subtitle}
        </p>
        <div className="w-16 h-1 mx-auto mb-4 bg-gradient-to-r from-[#FF6B8A] via-[#FFD93D] to-[#4ECDC4]" />
        <p className="font-['Press_Start_2P'] text-[7px] text-[#666]">
          © 2026 PixelMe — Made with ♥ & Pixels
        </p>
      </div>
    </footer>
  );
}
