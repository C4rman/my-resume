import { useState } from 'react';
import { school_experiences } from '../data/profile';

export default function CampusSection() {
  const [hoverId, setHoverId] = useState<string | null>(null);

  return (
    <section id="campus" className="py-20 px-6 pixel-grid-bg">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 mb-2 px-4 py-1 border-2 border-[#E8DDD4] bg-white">
            <span className="font-['Press_Start_2P'] text-[8px] text-[#8B8B8B]">SECTION 04</span>
          </div>
          <h2 className="font-['Press_Start_2P'] text-[#FF8C42] text-xl md:text-2xl mt-3 mb-3">
            🏫 校园经历
          </h2>
          <div className="pixel-divider max-w-xs mx-auto" />
        </div>

        <div className="space-y-6">
          {school_experiences.map((exp, i) => {
            const isActive = hoverId === exp.id;

            return (
              <div
                key={exp.id}
                className="relative group"
                onMouseEnter={() => setHoverId(exp.id)}
                onMouseLeave={() => setHoverId(null)}
              >
                {/* 左侧编号 */}
                <div className="hidden md:flex absolute -left-4 top-6 w-12 h-12 items-center justify-center border-[3px] border-[#4A4A4A] z-10 transition-transform group-hover:scale-110"
                  style={{ backgroundColor: exp.color + '22' }}>
                  <span className="font-['Press_Start_2P'] text-sm" style={{ color: exp.color }}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                </div>

                {/* 卡片 */}
                <div className="md:ml-12 pixel-card border-[3px] transition-all duration-300"
                  style={{
                    borderColor: isActive ? exp.color : '#4A4A4A',
                    boxShadow: isActive
                      ? `8px 8px 0 0 ${exp.color}44`
                      : '8px 8px 0 0 rgba(74,74,74,0.1)',
                  }}>
                  {/* 标题行 */}
                  <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
                    <div className="flex-1">
                      <h3 className="font-['Press_Start_2P'] text-[12px] text-[#4A4A4A] mb-1 leading-relaxed">
                        {exp.title}
                      </h3>
                      <div className="flex items-center gap-3 flex-wrap">
                        <span className="font-['VT323'] text-lg" style={{ color: exp.color }}>
                          {exp.role}
                        </span>
                        <span className="font-['Press_Start_2P'] text-[7px] text-[#8B8B8B]">
                          {exp.period}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 摘要 */}
                  <p className="font-['VT323'] text-lg text-[#4A4A4A] mb-4 leading-snug border-l-4 pl-4"
                    style={{ borderLeftColor: exp.color }}>
                    {exp.summary}
                  </p>

                  {/* 详情网格 */}
                  <div className="grid sm:grid-cols-2 gap-3">
                    {exp.highlights.map((h, j) => (
                      <div
                        key={j}
                        className="p-3 border-2 border-[#E8DDD4] font-['VT323'] text-base text-[#4A4A4A] leading-snug transition-all hover:bg-white hover:border-[#4A4A4A]"
                        style={{ borderLeftWidth: '4px', borderLeftColor: exp.color }}
                      >
                        <span className="font-['Press_Start_2P'] text-[7px] mr-2" style={{ color: exp.color }}>
                          ▪
                        </span>
                        {h}
                      </div>
                    ))}
                  </div>

                  {/* Hover 高亮条 */}
                  <div className="absolute bottom-0 left-0 right-0 h-1 transition-all duration-300"
                    style={{
                      backgroundColor: exp.color,
                      opacity: isActive ? 1 : 0,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
