import Navbar from './sections/Navbar';
import HeroSection from './sections/HeroSection';
import EducationSection from './sections/EducationSection';
import InternshipSection from './sections/InternshipSection';
import ProjectsSection from './sections/ProjectsSection';
import CampusSection from './sections/CampusSection';
import PortfolioSection from './sections/PortfolioSection';
import PersonalitySection from './sections/PersonalitySection';
import Footer from './sections/Footer';
import './App.css';

function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <HeroSection />
        <EducationSection />
        <InternshipSection />
        <ProjectsSection />
        <CampusSection />
        <PortfolioSection />
        <PersonalitySection />
      </main>
      <Footer />
    </div>
  );
}

export default App;
