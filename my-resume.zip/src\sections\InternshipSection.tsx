import { useState } from 'react';
import { internships } from '../data/profile';

export default function InternshipSection() {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <section id="internship" className="py-20 px-6 bg-white">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 mb-2 px-4 py-1 border-2 border-[#E8DDD4] bg-[#FFF8F0]">
            <span className="font-['Press_Start_2P'] text-[8px] text-[#8B8B8B]">SECTION 02</span>
          </div>
          <h2 className="font-['Press_Start_2P'] text-[#FF8C42] text-xl md:text-2xl mt-3 mb-3">
            💼 实习经历
          </h2>
          <div className="pixel-divider max-w-xs mx-auto" />
        </div>

        {/* 时间线 */}
        <div className="relative">
          {/* 轴线 */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-1 bg-[#E8DDD4] transform md:-translate-x-1/2 rounded-full" />

          <div className="space-y-12">
            {internships.map((intern, index) => {
              const isLeft = index % 2 === 0;
              const isExpanded = expandedId === intern.id;

              return (
                <div
                  key={intern.id}
                  className={`relative flex flex-col md:flex-row items-start ${isLeft ? 'md:flex-row' : 'md:flex-row-reverse'}`}
                >
                  {/* 时间节点 */}
                  <div className="absolute left-4 md:left-1/2 transform -translate-x-1/2 z-10">
                    <div
                      className="w-5 h-5 rotate-45 border-2 border-[#4A4A4A] transition-transform hover:scale-125 cursor-pointer"
                      style={{ backgroundColor: intern.color }}
                      onClick={() => toggleExpand(intern.id)}
                    />
                  </div>

                  {/* 卡片 */}
                  <div
                    className={`ml-12 md:ml-0 md:w-[calc(50%-2rem)] ${isLeft ? 'md:pr-10' : 'md:pl-10'}`}
                  >
                    <div
                      className="pixel-card cursor-pointer group transition-all duration-300"
                      style={{
                        borderColor: isExpanded ? intern.color : '#4A4A4A',
                        boxShadow: isExpanded
                          ? `8px 8px 0 0 ${intern.color}44`
                          : '8px 8px 0 0 rgba(74,74,74,0.1)',
                      }}
                      onClick={() => toggleExpand(intern.id)}
                    >
                      {/* 头部 */}
                      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                        <div>
                          <h3 className="font-['Press_Start_2P'] text-[12px] text-[#4A4A4A] mb-1">
                            {intern.role}
                          </h3>
                          <p
                            className="font-['Press_Start_2P'] text-[9px]"
                            style={{ color: intern.color }}
                          >
                            @ {intern.company}
                          </p>
                        </div>
                        <span className="font-['VT323'] text-base text-[#8B8B8B]">
                          {intern.period}
                        </span>
                      </div>

                      {/* 摘要 */}
                      <p className="font-['VT323'] text-lg text-[#4A4A4A] leading-snug mb-3">
                        {intern.summary}
                      </p>

                      {/* 展开提示 */}
                      <div className="flex items-center gap-2 font-['Press_Start_2P'] text-[8px]"
                        style={{ color: intern.color }}>
                        <span>{isExpanded ? '▲ 收起' : '▼ 展开详情'}</span>
                        <span className="font-['VT323'] text-base">
                          ({intern.achievements.length} 项成果)
                        </span>
                      </div>

                      {/* 展开内容 */}
                      <div
                        className={`overflow-hidden transition-all duration-500 ${
                          isExpanded ? 'max-h-[2000px] mt-4 pt-4 border-t-2 border-dashed border-[#E8DDD4]' : 'max-h-0'
                        }`}
                      >
                        <ul className="space-y-3">
                          {intern.achievements.map((ach, j) => (
                            <li
                              key={j}
                              className="flex items-start gap-2 font-['VT323'] text-lg text-[#4A4A4A] leading-snug"
                            >
                              <span
                                className="mt-1 shrink-0 font-['Press_Start_2P'] text-[8px]"
                                style={{ color: intern.color }}
                              >
                                0{j + 1}
                              </span>
                              <span>{ach}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
