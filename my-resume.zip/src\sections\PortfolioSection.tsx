import { useState } from 'react';
import { portfolio } from '../data/profile';

export default function PortfolioSection() {
  const [activeId, setActiveId] = useState<string | null>(null);

  return (
    <section id="portfolio" className="py-20 px-6 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 mb-2 px-4 py-1 border-2 border-[#E8DDD4] bg-[#FFF8F0]">
            <span className="font-['Press_Start_2P'] text-[8px] text-[#8B8B8B]">SECTION 04</span>
          </div>
          <h2 className="font-['Press_Start_2P'] text-[#5B8DEF] text-xl md:text-2xl mt-3 mb-3">
            🎨 作品集
          </h2>
          <div className="pixel-divider max-w-xs mx-auto" />
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          {portfolio.map((item) => {
            const isActive = activeId === item.id;
            return (
              <div
                key={item.id}
                className="group cursor-pointer"
                onClick={() => setActiveId(isActive ? null : item.id)}
              >
                {/* 封面区 */}
                <div
                  className="h-40 flex flex-col items-center justify-center border-4 border-b-0 border-[#4A4A4A] relative overflow-hidden transition-all duration-300"
                  style={{
                    backgroundColor: `${item.color}18`,
                  }}
                >
                  {/* 像素粒子装饰 */}
                  <div className="absolute inset-0">
                    {[...Array(8)].map((_, j) => (
                      <span
                        key={j}
                        className="absolute w-2 h-2 opacity-30"
                        style={{
                          left: `${10 + j * 12}%`,
                          top: `${20 + (j % 3) * 25}%`,
                          backgroundColor: item.color,
                        }}
                      />
                    ))}
                  </div>

                  <span className="text-5xl relative z-10 mb-2">{item.cover}</span>
                  <span
                    className="font-['Press_Start_2P'] text-[9px] relative z-10 text-center px-4 leading-relaxed"
                    style={{ color: item.color }}
                  >
                    {item.title}
                  </span>
                </div>

                {/* 内容区 */}
                <div
                  className="p-5 border-4 border-[#4A4A4A] bg-white transition-all duration-300"
                  style={{
                    backgroundColor: isActive ? `${item.color}08` : 'white',
                  }}
                >
                  {/* 副标题 + 角色 */}
                  <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                    <p className="font-['VT323'] text-lg" style={{ color: item.color }}>
                      {item.subtitle}
                    </p>
                    <span className="font-['Press_Start_2P'] text-[7px] text-[#8B8B8B]">
                      {item.role}
                    </span>
                  </div>

                  {/* 描述 */}
                  <p className="font-['VT323'] text-base text-[#4A4A4A] mb-4 leading-snug">
                    {item.description}
                  </p>

                  {/* 展开详情 */}
                  <div className={`overflow-hidden transition-all duration-500 ${isActive ? 'max-h-[800px] mb-4' : 'max-h-0'}`}>
                    <ul className="space-y-2 pt-2 border-t-2 border-dashed border-[#E8DDD4]">
                      {item.details.map((d, j) => (
                        <li key={j} className="flex items-start gap-2 font-['VT323'] text-base text-[#4A4A4A]">
                          <span style={{ color: item.color }}>▹</span>
                          <span>{d}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* 标签 */}
                  <div className="flex flex-wrap gap-1.5">
                    {item.tags.map((tag, j) => (
                      <span
                        key={j}
                        className="font-['Press_Start_2P'] text-[7px] px-2 py-1 border-2 transition-all hover:scale-105"
                        style={{
                          borderColor: item.color,
                          color: item.color,
                          backgroundColor: `${item.color}10`,
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* 点击提示 */}
                  <div className="mt-3 font-['Press_Start_2P'] text-[8px]"
                    style={{ color: item.color }}>
                    {isActive ? '▲ 收起' : '▼ 点击展开详情'}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
