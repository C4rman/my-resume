import { useState } from 'react';
import { education } from '../data/profile';

export default function EducationSection() {
  const [activeIdx, setActiveIdx] = useState<number | null>(null);

  return (
    <section id="education" className="py-20 px-6 pixel-grid-bg">
      <div className="max-w-5xl mx-auto">
        {/* 标题 */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 mb-2 px-4 py-1 border-2 border-[#E8DDD4] bg-white">
            <span className="font-['Press_Start_2P'] text-[8px] text-[#8B8B8B]">SECTION 01</span>
          </div>
          <h2 className="font-['Press_Start_2P'] text-[#4ECDC4] text-xl md:text-2xl mt-3 mb-3">
            🎓 教育经历
          </h2>
          <div className="pixel-divider max-w-xs mx-auto" />
        </div>

        {/* 双卡片 */}
        <div className="grid md:grid-cols-2 gap-8">
          {education.map((edu, i) => (
            <div
              key={edu.id}
              className="relative group cursor-pointer"
              onMouseEnter={() => setActiveIdx(i)}
              onMouseLeave={() => setActiveIdx(null)}
            >
              {/* 装饰角标 */}
              <div
                className="absolute -top-3 -right-3 w-8 h-8 border-2 border-[#4A4A4A] z-10 flex items-center justify-center transition-transform group-hover:rotate-12"
                style={{ backgroundColor: edu.color }}
              >
                <span className="font-['Press_Start_2P'] text-[7px] text-white">{i + 1}</span>
              </div>

              {/* 卡片主体 */}
              <div
                className="pixel-card h-full border-[3px] transition-all duration-300"
                style={{
                  borderColor: activeIdx === i ? edu.color : '#4A4A4A',
                  boxShadow: activeIdx === i
                    ? `8px 8px 0 0 ${edu.color}44`
                    : '8px 8px 0 0 rgba(74,74,74,0.1)',
                }}
              >
                {/* 学位标签 + 时间 */}
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <span
                    className="font-['Press_Start_2P'] text-[9px] px-3 py-1.5 border-2"
                    style={{
                      borderColor: edu.color,
                      color: edu.color,
                      backgroundColor: `${edu.color}18`,
                    }}
                  >
                    {edu.degree}
                  </span>
                  <span className="font-['VT323'] text-base text-[#8B8B8B] tracking-wide">
                    {edu.period}
                  </span>
                </div>

                {/* 校名 */}
                <h3 className="font-['Press_Start_2P'] text-[13px] text-[#4A4A4A] mb-1 leading-relaxed">
                  {edu.school}
                </h3>
                <p className="font-['VT323'] text-xl mb-1" style={{ color: edu.color }}>
                  {edu.department}
                </p>
                <p className="font-['VT323'] text-lg text-[#8B8B8B] mb-4">
                  {edu.major}
                </p>

                {/* 研究方向 */}
                <div className="border-t-2 border-dashed border-[#E8DDD4] pt-4 mt-2">
                  <span className="font-['Press_Start_2P'] text-[7px] text-[#8B8B8B] block mb-3">
                    ▸ 研究方向
                  </span>
                  <ul className="space-y-2">
                    {edu.highlights.map((h, j) => (
                      <li
                        key={j}
                        className="flex items-start gap-2 font-['VT323'] text-lg text-[#4A4A4A] leading-snug"
                      >
                        <span className="mt-1 shrink-0" style={{ color: edu.color }}>
                          {['▸', '▹', '▪'][j]}
                        </span>
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
