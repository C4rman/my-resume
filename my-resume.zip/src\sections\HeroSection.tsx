import { personalInfo } from '../data/profile';

export default function HeroSection() {
  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden pixel-grid-bg pt-20">
      {/* 浮动粒子 */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(24)].map((_, i) => (
          <div
            key={i}
            className="pixel-particle"
            style={{
              left: `${(i * 37 + 11) % 100}%`,
              top: `${(i * 53 + 7) % 100}%`,
              backgroundColor: ['#FF6B8A', '#7EC8E3', '#FFE066', '#98D8C8', '#C4A6FF', '#FF9A76'][i % 6],
              animationDelay: `${(i * 0.3) % 3}s`,
              animationDuration: `${2.5 + (i % 3) * 0.8}s`,
              width: `${6 + (i % 4) * 2}px`,
              height: `${6 + (i % 4) * 2}px`,
            }}
          />
        ))}
      </div>

      <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
        {/* 真实头像 */}
        <div className="mb-8 inline-block">
          <div className="pixel-avatar w-32 h-32 mx-auto bg-white overflow-hidden border-[3px] border-[#4A4A4A] shadow-[6px_6px_0_0_#4A4A4A22]">
            <img
              src="/avatar.png"
              alt={personalInfo.name}
              className="w-full h-full object-cover"
              style={{ imageRendering: 'crisp-edges' }}
            />
          </div>
        </div>

        {/* 姓名 + 状态指示 */}
        <div className="inline-flex items-center gap-3 mb-3">
          <span className="w-3 h-3 bg-[#4ECDC4] border-2 border-[#4A4A4A] animate-pulse" />
          <span className="font-['Press_Start_2P'] text-[8px] text-[#4ECDC4]">ONLINE</span>
        </div>

        <h1 className="font-['Press_Start_2P'] text-[#FF6B8A] text-2xl md:text-4xl mb-3 leading-relaxed">
          {personalInfo.name}
        </h1>

        {/* 副标题 */}
        <p className="font-['Press_Start_2P'] text-[#5B8DEF] text-[10px] md:text-[12px] mb-4">
          {personalInfo.subtitle}
        </p>

        {/* 标签 */}
        <div className="flex flex-wrap justify-center gap-3 mb-6">
          <span className="pixel-tag pixel-tag-pink">🎮 游戏策划</span>
          <span className="pixel-tag pixel-tag-blue">📱 产品经理</span>
          <span className="pixel-tag pixel-tag-mint">🎨 像素艺术家</span>
          <span className="pixel-tag pixel-tag-yellow">📝 内容创作者</span>
        </div>

        {/* 标语 */}
        <p className="font-['VT323'] text-[#8B8B8B] text-xl md:text-2xl mb-4 max-w-2xl mx-auto leading-relaxed">
          {personalInfo.tagline}
        </p>

        {/* 简介 */}
        <p className="font-['VT323'] text-lg text-[#4A4A4A] mb-8 max-w-xl mx-auto bg-white/60 backdrop-blur-sm px-6 py-3 border-2 border-dashed border-[#E8DDD4]">
          📍 {personalInfo.brief}
        </p>

        {/* CTA */}
        <div className="flex flex-wrap justify-center gap-4">
          <button
            onClick={() => document.getElementById('education')?.scrollIntoView({ behavior: 'smooth' })}
            className="pixel-btn pixel-btn-primary flex items-center gap-2"
          >
            <span>▶</span> 查看简历
          </button>
          <button
            onClick={() => document.getElementById('personality')?.scrollIntoView({ behavior: 'smooth' })}
            className="pixel-btn flex items-center gap-2"
          >
            <span>✉</span> 联系我
          </button>
        </div>

        {/* 下箭头 */}
        <div className="mt-16 animate-bounce">
          <span className="font-['Press_Start_2P'] text-[#4A4A4A] text-xl">▼</span>
        </div>
      </div>
    </section>
  );
}
