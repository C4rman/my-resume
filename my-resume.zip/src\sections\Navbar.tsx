import { useState } from 'react';
import { personalInfo, navItems } from '../data/profile';

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
    setMobileOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#FFF8F0]/95 backdrop-blur-sm border-b-4 border-[#4A4A4A]">
      <div className="max-w-6xl mx-auto px-4 md:px-6 py-3 flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-all group shrink-0"
        >
          <span className="text-2xl group-hover:scale-110 transition-transform">
            {personalInfo.avatar}
          </span>
          <span className="font-['Press_Start_2P'] text-[9px] text-[#FF6B8A] hidden sm:block">
            {personalInfo.name}
          </span>
        </button>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className="font-['Press_Start_2P'] text-[9px] px-2.5 py-2 text-[#4A4A4A] hover:text-[#FF6B8A] hover:bg-[#FFE8EC] transition-all cursor-pointer border-2 border-transparent hover:border-[#FF6B8A] whitespace-nowrap"
            >
              <span className="mr-1">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </div>

        {/* Mobile Toggle */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="md:hidden font-['Press_Start_2P'] text-[14px] text-[#4A4A4A] cursor-pointer hover:text-[#FF6B8A] transition-colors"
        >
          {mobileOpen ? '✕' : '☰'}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden bg-[#FFF8F0] border-t-4 border-[#4A4A4A] px-4 py-2 animate-fadeInUp">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className="flex items-center gap-2 w-full text-left font-['Press_Start_2P'] text-[10px] py-3 text-[#4A4A4A] hover:text-[#FF6B8A] cursor-pointer transition-colors border-b border-[#E8DDD4] last:border-b-0"
            >
              <span>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </div>
      )}
    </nav>
  );
}
