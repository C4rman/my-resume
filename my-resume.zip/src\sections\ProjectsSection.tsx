import { useState } from 'react';
import { projects } from '../data/profile';

export default function ProjectsSection() {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <section id="projects" className="py-20 px-6 pixel-grid-bg">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 mb-2 px-4 py-1 border-2 border-[#E8DDD4] bg-white">
            <span className="font-['Press_Start_2P'] text-[8px] text-[#8B8B8B]">SECTION 03</span>
          </div>
          <h2 className="font-['Press_Start_2P'] text-[#A66CFF] text-xl md:text-2xl mt-3 mb-3">
            🚀 项目经历
          </h2>
          <div className="pixel-divider max-w-xs mx-auto" />
        </div>

        <div className="space-y-6">
          {projects.map((project, i) => {
            const isExpanded = expandedId === project.id;

            return (
              <div key={project.id} className="relative">
                {/* 左侧编号 */}
                <div
                  className="hidden md:flex absolute -left-4 top-6 w-12 h-12 items-center justify-center border-[3px] border-[#4A4A4A] z-10 transition-transform hover:scale-110 cursor-pointer"
                  style={{ backgroundColor: project.color + '22' }}
                  onClick={() => toggleExpand(project.id)}
                >
                  <span className="font-['Press_Start_2P'] text-sm" style={{ color: project.color }}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                </div>

                {/* 卡片 */}
                <div
                  className="md:ml-12 pixel-card border-[3px] transition-all duration-300 cursor-pointer"
                  style={{
                    borderColor: isExpanded ? project.color : '#4A4A4A',
                    boxShadow: isExpanded
                      ? `8px 8px 0 0 ${project.color}44`
                      : '8px 8px 0 0 rgba(74,74,74,0.1)',
                  }}
                  onClick={() => toggleExpand(project.id)}
                >
                  {/* 标题行 */}
                  <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
                    <div className="flex-1">
                      <h3 className="font-['Press_Start_2P'] text-[12px] text-[#4A4A4A] mb-1 leading-relaxed">
                        {project.title}
                      </h3>
                      <div className="flex items-center gap-3 flex-wrap">
                        <span className="font-['VT323'] text-lg" style={{ color: project.color }}>
                          {project.role}
                        </span>
                        <span className="font-['Press_Start_2P'] text-[7px] text-[#8B8B8B]">
                          {project.period}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 摘要 */}
                  <p className="font-['VT323'] text-lg text-[#4A4A4A] mb-4 leading-snug border-l-4 pl-4"
                    style={{ borderLeftColor: project.color }}>
                    {project.summary}
                  </p>

                  {/* 展开 / 收起提示 */}
                  <div className="flex items-center gap-2 font-['Press_Start_2P'] text-[8px]"
                    style={{ color: project.color }}>
                    <span>{isExpanded ? '▲ 收起详情' : '▼ 展开详情'}</span>
                    <span className="font-['VT323'] text-base">
                      ({project.highlights.length} 项亮点)
                    </span>
                  </div>

                  {/* 展开内容：详情网格 */}
                  <div
                    className={`overflow-hidden transition-all duration-500 ${
                      isExpanded ? 'max-h-[2000px] mt-4 pt-4 border-t-2 border-dashed border-[#E8DDD4]' : 'max-h-0'
                    }`}
                  >
                    <div className="grid sm:grid-cols-2 gap-3">
                      {project.highlights.map((h, j) => (
                        <div
                          key={j}
                          className="p-3 border-2 border-[#E8DDD4] font-['VT323'] text-base text-[#4A4A4A] leading-snug transition-all hover:bg-white hover:border-[#4A4A4A]"
                          style={{ borderLeftWidth: '4px', borderLeftColor: project.color }}
                        >
                          <span className="font-['Press_Start_2P'] text-[7px] mr-2" style={{ color: project.color }}>
                            ▪
                          </span>
                          {h}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 展开高亮条 */}
                  <div className="absolute bottom-0 left-0 right-0 h-1 transition-all duration-300"
                    style={{
                      backgroundColor: project.color,
                      opacity: isExpanded ? 1 : 0,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
